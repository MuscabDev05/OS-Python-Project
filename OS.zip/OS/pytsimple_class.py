class Player:
    def __init__(self, name, score):
        self.name = name 
        self.score = score 



    def add_points(self, amount):
    # Increase the score by the given amount
        self.score = self.score + amount

    def show_info(self):
        print("Player:", self.name, "Score:", self.score)

# Create one player
p = Player("Jordan", 5)

# Use the methods 
p.show_info()
p.add_points(10)
p.show_info()