import os

print('--- File Organizer ---')
folder = input('Folder to organize: ').strip()

if not os.path.isdir(folder):
    print('Folder not found.')
    exit()

for item in os.listdir(folder):
    path = os.path.join(folder, item)
    if os.path.isfile(path):
        ext = item.split('.')[-1].lower() if '.' in item else 'no_ext'
        target = os.path.join(folder, ext)
        os.makedirs(target, exist_ok=True)
        os.rename(path, os.path.join(target, item))

print('Done. Files grouped by extension.')