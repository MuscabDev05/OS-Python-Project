from game_engine import GameEngine

def main():
    engine = GameEngine()
    engine.setup()
    engine.setup()
    engine.main_loop()

if __name__ == "__main__":
    main()
    